'use client';
import { useMemo, useState } from "react";
import { matches, type Match } from "@/lib/data";

type Pick={matchId:number;index:number};
const labels=["1","X","2"];

export default function BettingApp(){
 const [filter,setFilter]=useState<"all"|"live"|"popular">("all");
 const [picks,setPicks]=useState<Pick[]>([]);
 const [couponOpen,setCouponOpen]=useState(false);
 const [stake,setStake]=useState(500);

 const visible=useMemo(()=>filter==="live"?matches.filter(m=>m.live):filter==="popular"?[matches[1],matches[0],matches[3]]:matches,[filter]);
 const selected=(id:number,i:number)=>picks.some(p=>p.matchId===id&&p.index===i);
 function toggle(m:Match,i:number){
   setPicks(old=>{
     const same=old.findIndex(p=>p.matchId===m.id);
     if(same>=0) return old[same].index===i?old.filter((_,x)=>x!==same):old.map((p,x)=>x===same?{matchId:m.id,index:i}:p);
     return [...old,{matchId:m.id,index:i}];
   });
   setCouponOpen(true);
 }
 const total=picks.reduce((acc,p)=>acc*(matches.find(m=>m.id===p.matchId)?.odds[p.index]||1),1);
 const potential=Math.round(stake*total);

 return <div className="shell">
  <header className="top"><div className="brand"><span className="logo">G</span>GOALIX</div><span>⌕</span><div className="balance">◉ 200 FCFA <b>+</b></div></header>
  <main>
   <section className="hero"><span className="eyebrow">PLATEFORME SPORTIVE</span><h1>Le sport.<br/><em>En direct.</em></h1><p>Une expérience rapide, moderne et pensée pour le mobile.</p></section>
   <div className="toolbar">{["all","live","popular"].map(x=><button key={x} className={"chip "+(filter===x?"active":"")} onClick={()=>setFilter(x as typeof filter)}>{x==="all"?"⚽ Football":x==="live"?"🔴 En direct":"🔥 Populaires"}</button>)}</div>
   <section className="ai"><div className="star">✦</div><div style={{flex:1}}><span className="eyebrow" style={{color:"#a8ef00"}}>IA PRONO</span><h2>Génère ton coupon</h2><p>Une sélection assistée par les données disponibles.</p></div><button onClick={()=>alert("La génération IA avancée sera branchée à l’API sportive dans l’étape suivante.")}>Créer</button></section>
   <div className="title"><div><span className="eyebrow">{filter==="live"?"LIVE":"SÉLECTION"}</span><h2>{filter==="live"?"Matchs en direct":"Matchs du jour"}</h2></div><button onClick={()=>setFilter("all")}>Tout voir →</button></div>
   {visible.map(m=><article className="match" key={m.id}>
     <div className="meta"><span>{m.league}</span><span className={m.live?"live":""}>{m.start}</span></div>
     <div className="teams"><div className="team">{m.home}</div><div className="score">{m.live?m.score:"vs"}</div><div className="team away">{m.away}</div></div>
     <div className="odds">{m.odds.map((odd,i)=><button key={i} className={"odd "+(selected(m.id,i)?"selected":"")} onClick={()=>toggle(m,i)}><small>{labels[i]}{m.live?" • LIVE":""}</small><strong>{odd.toFixed(2)}</strong></button>)}</div>
   </article>)}
  </main>
  <section className={"coupon "+(couponOpen?"open":"")}>
   <div className="coupon-head"><div><span className="eyebrow">TON COUPON</span><h3>{picks.length} sélection(s)</h3></div><button className="x" onClick={()=>setCouponOpen(false)}>×</button></div>
   <div className="coupon-items">{picks.length===0?<p style={{color:"#78847e",fontSize:13}}>Ajoute une cote pour commencer.</p>:picks.map((p,i)=>{const m=matches.find(x=>x.id===p.matchId)!;return <div className="item" key={i}><div><b>{m.home} — {m.away}</b><small>1X2 • {labels[p.index]} • {m.odds[p.index].toFixed(2)}</small></div><button className="x" onClick={()=>toggle(m,p.index)}>×</button></div>})}</div>
   <div className="coupon-foot"><div className="row"><span>Cote totale</span><b>{picks.length?total.toFixed(2):"0.00"}</b></div><input className="stake" type="number" value={stake} min={0} onChange={e=>setStake(Number(e.target.value))}/><div className="row"><span>Gain potentiel</span><b>{potential.toLocaleString("fr-FR")} FCFA</b></div><button className="primary" onClick={()=>alert("Mode simulation : le pari réel sera traité côté serveur dans une prochaine version.")}>PARIER</button></div>
  </section>
  <nav className="nav">{["⌂|Accueil","⚽|Sports","◉|Direct","🎟|Coupon","♙|Compte"].map((x,i)=>{const [a,b]=x.split("|");return <button key={b} className={i===0?"active":""} onClick={()=>i===3&&setCouponOpen(v=>!v)}>{a}<span>{b}</span></button>})}</nav>
 </div>
}
