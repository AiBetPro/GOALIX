import {matches, Match} from './demo-data';

export type Risk='prudente'|'equilibree'|'audacieuse';

function clamp(n:number){return Math.max(0.05,Math.min(0.95,n));}

export function rankMatches(risk:Risk='equilibree'){
  const rows = matches.map((m:Match)=>{
    const base = 0.55*m.homeForm + 0.25*(m.homeGoals/(m.homeGoals+m.awayGoals)) + 0.20*(0.5+m.homeAdvantage);
    const probability = clamp(base);
    const value = probability*m.odds.home;
    const riskPenalty = risk==='prudente' ? Math.abs(m.odds.home-1.5)*0.05 : risk==='audacieuse' ? 0 : Math.abs(m.odds.home-1.8)*0.02;
    const score = clamp(probability-riskPenalty);
    return {matchId:m.id, home:m.home, away:m.away, market:'1', odds:m.odds.home, probability:Number(probability.toFixed(3)), score:Number(score.toFixed(3)), value:Number(value.toFixed(3)),
      reason:`Forme domicile ${(m.homeForm*100).toFixed(0)}%, moyenne buts ${m.homeGoals.toFixed(1)} et avantage domicile.`};
  }).sort((a,b)=>b.score-a.score);
  return rows;
}

export function generateCoupon(risk:Risk='equilibree', count=3){
  const rows=rankMatches(risk).slice(0,Math.max(1,Math.min(5,count)));
  const totalOdds=rows.reduce((p,r)=>p*r.odds,1);
  return {risk, selections:rows, totalOdds:Number(totalOdds.toFixed(2)), disclaimer:'Estimation statistique de démonstration. Aucun gain n’est garanti.'};
}