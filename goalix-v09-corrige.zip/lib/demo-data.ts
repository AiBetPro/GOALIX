export type Match = {
  id:string; home:string; away:string; odds:{home:number; draw:number; away:number};
  homeForm:number; awayForm:number; homeGoals:number; awayGoals:number; homeAdvantage:number;
};

export const matches:Match[] = [
 {id:'m1',home:'Arsenal',away:'Chelsea',odds:{home:1.72,draw:3.85,away:4.65},homeForm:0.82,awayForm:0.58,homeGoals:2.1,awayGoals:1.3,homeAdvantage:0.08},
 {id:'m2',home:'Man City',away:'Real Madrid',odds:{home:1.95,draw:3.70,away:3.55},homeForm:0.79,awayForm:0.76,homeGoals:2.4,awayGoals:2.0,homeAdvantage:0.06},
 {id:'m3',home:'Monaco',away:'Lyon',odds:{home:2.05,draw:3.45,away:3.40},homeForm:0.68,awayForm:0.61,homeGoals:1.8,awayGoals:1.4,homeAdvantage:0.07},
 {id:'m4',home:'Al Ahly',away:'APR FC',odds:{home:1.48,draw:4.20,away:6.20},homeForm:0.88,awayForm:0.52,homeGoals:2.0,awayGoals:0.9,homeAdvantage:0.10}
];