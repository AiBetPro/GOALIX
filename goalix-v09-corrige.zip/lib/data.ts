export type Match = {
  id:number; league:string; start:string; home:string; away:string;
  live:boolean; score?:string; odds:[number,number,number]
};
export const matches: Match[] = [
 {id:1,league:"Premier League",start:"Aujourd’hui • 19:45",home:"Arsenal",away:"Chelsea",live:false,odds:[1.82,3.70,4.25]},
 {id:2,league:"Serie A",start:"Aujourd’hui • 20:00",home:"Venezia FC",away:"Fiorentina",live:false,odds:[2.69,3.42,2.59]},
 {id:3,league:"CAF Champions League",start:"Demain • 17:00",home:"APR FC",away:"Al Ahly",live:false,odds:[4.20,3.25,1.75]},
 {id:4,league:"Match en direct",start:"🔴 LIVE • 67’",home:"Manchester City",away:"Real Madrid",live:true,score:"2 — 1",odds:[1.18,6.20,12.00]},
 {id:5,league:"Ligue 1",start:"🔴 LIVE • 54’",home:"Paris FC",away:"Monaco",live:true,score:"1 — 1",odds:[2.05,3.30,3.05]}
];
