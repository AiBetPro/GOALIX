# GOALIX V0.9 corrigé

Base de développement du site de paris sportifs GOALIX.

## Inclus
- Interface d'accueil et navigation
- Dashboard matchs + coupon de démonstration
- Page Live + API Sportmonks
- Page Bets + API de paris
- Page IA Prono + API de génération de coupon
- Prisma + PostgreSQL
- Structure `components/`
- Validation serveur des paris dans une transaction Prisma

## Important
Cette version utilise encore de l'argent fictif et certaines données de démonstration. Le compte utilisateur de seed n'est pas une authentification de production.

Avant tout argent réel, il faut ajouter une authentification robuste, des contrôles d'accès, la gestion réelle des cotes/règlements, audit, anti-fraude, KYC, jeu responsable et conformité/licence applicables.

## Installation
1. Copier `.env.example` vers `.env`.
2. Renseigner `DATABASE_URL`.
3. Installer les dépendances : `npm install`.
4. Générer Prisma : `npx prisma generate`.
5. Migrer : `npx prisma migrate dev --name init`.
6. Seed : `npx prisma db seed`.
7. Lancer : `npm run dev`.

Pour les données Sportmonks, renseigner également `SPORTMONKS_TOKEN` dans l'environnement de déploiement. Ne jamais publier une vraie clé secrète dans GitHub.
