'use client';
import {useState} from 'react';
const games=[['🔴','Man City','Real Madrid','67’','2 - 1',['1.95','3.70','3.55']],['','Arsenal','Chelsea','20:00','—',['1.72','3.85','4.65']],['','Al Ahly','APR FC','21:00','—',['1.48','4.20','6.20']],['','Monaco','Lyon','21:30','—',['2.05','3.45','3.40']]];
export default function Dashboard(){
 const [slip,setSlip]=useState<{game:string;pick:string;odd:string}[]>([]);
 const add=(game:string,pick:string,odd:string)=>setSlip(x=>[...x.filter(a=>a.game!==game),{game,pick,odd}]);
 const total=slip.reduce((p,x)=>p*Number(x.odd),1);
 return <main className="shell"><header className="top"><a href="/">← GOALIX</a><span className="pill">MON COMPTE · 10 000 FCFA</span></header>
 <div className="layout"><section><div className="panel"><p className="eyebrow">MATCHS</p><h1>Football</h1>{games.map((g,i)=><article className="match" key={i}><div><small>{g[0]} {g[3]}</small><b>{g[1]} — {g[2]}</b><span>{g[4]}</span></div><div className="odds">{g[5].map((o,j)=><button key={j} onClick={()=>add(`${g[1]} - ${g[2]}`,['1','X','2'][j],o)}>{['1','X','2'][j]}<strong>{o}</strong></button>)}</div></article>)}</div></section>
 <aside className="panel slip"><h2>🎟️ Mon coupon</h2>{slip.length===0?<p className="muted">Sélectionne une cote pour commencer.</p>:slip.map((s,i)=><div className="sliprow" key={i}><span>{s.game}<small>{s.pick}</small></span><b>{s.odd}</b></div>)}<hr/><div className="couponTotal"><span>Cote totale</span><b>{slip.length?total.toFixed(2):'—'}</b></div><button className="button" disabled={!slip.length}>Parier · argent fictif</button></aside></div>
 </main>
}