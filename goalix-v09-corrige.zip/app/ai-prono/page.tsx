'use client';
import {useEffect,useState} from 'react';

type Coupon={risk:string; totalOdds:number; disclaimer:string; selections:Array<{home:string;away:string;odds:number;probability:number;score:number;reason:string}>};

export default function AIProno(){
 const [risk,setRisk]=useState('equilibree'); const [count,setCount]=useState(3); const [coupon,setCoupon]=useState<Coupon|null>(null); const [loading,setLoading]=useState(false);
 async function generate(){setLoading(true); const r=await fetch('/api/ai/coupon',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({risk,count})}); setCoupon(await r.json()); setLoading(false);}
 useEffect(()=>{generate()},[]);
 return <main className="shell">
  <header className="top"><a href="/">← GOALIX</a><span className="pill">🤖 IA PRONO</span></header>
  <section className="panel">
   <p className="eyebrow">GÉNÉRATEUR</p><h1>Ton coupon intelligent</h1>
   <div className="controls"><label>Risque<select value={risk} onChange={e=>setRisk(e.target.value)}><option value="prudente">Prudente</option><option value="equilibree">Équilibrée</option><option value="audacieuse">Audacieuse</option></select></label><label>Matchs<select value={count} onChange={e=>setCount(Number(e.target.value))}><option>2</option><option>3</option><option>4</option><option>5</option></select></label></div>
   <button className="button" onClick={generate}>{loading?'Analyse…':'Générer mon coupon'}</button>
  </section>
  {coupon && <section className="panel"><div className="couponHead"><h2>Coupon {coupon.risk}</h2><strong>Cote {coupon.totalOdds}</strong></div>
   {coupon.selections.map((s,i)=><article className="pick" key={i}><div><b>{s.home} — {s.away}</b><p>Victoire domicile · {s.reason}</p></div><span>{s.odds.toFixed(2)}</span></article>)}
   <p className="notice">⚠️ {coupon.disclaimer}</p>
  </section>}
 </main>
}