'use client';
import {useEffect,useState} from 'react';
type Game={id:number;name?:string;scores?:any[];participants?:any[];state?:any};
export default function Live(){
 const [games,setGames]=useState<Game[]>([]); const [configured,setConfigured]=useState(false); const [err,setErr]=useState('');
 async function load(){try{const r=await fetch('/api/live',{cache:'no-store'});const j=await r.json();setConfigured(!!j.configured);setGames(j.data||[]);if(j.error)setErr(j.error)}catch(e){setErr(String(e))}}
 useEffect(()=>{load();const x=setInterval(load,10000);return()=>clearInterval(x)},[]);
 return <main className="shell"><header className="top"><a href="/">← GOALIX</a><span className="pill">🔴 LIVE</span></header>
 <section className="panel"><p className="eyebrow">SCORES EN DIRECT</p><h1>Matchs live</h1>
 {!configured&&<div className="notice">Mode démo : ajoute <b>SPORTMONKS_TOKEN</b> dans .env.local pour recevoir les vrais matchs.</div>}
 {err&&<div className="notice">⚠️ {err}</div>}
 {games.length===0&&!err&&<p className="muted">Aucun match live disponible pour le moment.</p>}
 {games.map((g,i)=><article className="match" key={g.id||i}><div><small>🔴 EN DIRECT · {g.state?.name||'LIVE'}</small><b>{g.name||`Fixture #${g.id}`}</b></div><span>{g.scores?.map((s:any)=>s.score?.goals??s.goals).filter((x:any)=>x!==undefined).join(' - ')||'—'}</span></article>)}
 </section>
 </main>
}