import Link from 'next/link';

export default function Home(){
 return <main className="shell">
  <header className="top"><div className="brand">GOALIX</div><nav><Link href="/dashboard">Sports</Link><Link href="/ai-prono">🤖 IA Prono</Link></nav></header>
  <section className="hero"><p className="eyebrow">PARIS SPORTIFS · V0.6</p><h1>Tout ton univers sportif, <span>au même endroit.</span></h1>
   <p>Matchs, live, coupon et IA Prono dans une interface unique. Version de démonstration avec argent fictif.</p>
   <div><Link className="button" href="/dashboard">Voir les matchs →</Link> <Link className="button secondary" href="/ai-prono">🤖 Générer un coupon</Link></div>
  </section>
  <section className="cards">
   <article><b>🔴 LIVE</b><p>Une structure prête pour les scores et événements en temps réel.</p></article>
   <article><b>🎟️ COUPON</b><p>Sélections, cote totale et gain potentiel calculé côté application.</p></article>
   <article><b>🤖 IA PRONO</b><p>Classe les opportunités selon ton niveau de risque.</p></article>
  </section>
 </main>
}