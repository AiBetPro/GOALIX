import './globals.css';
import type { ReactNode } from 'react';

export const metadata = { title: 'Goalix — IA Prono', description: 'Prototype de paris sportifs avec assistant IA' };

export default function RootLayout({children}:{children:ReactNode}) {
  return <html lang="fr"><body>{children}</body></html>;
}