import {NextResponse} from 'next/server';

let profile={risk:'equilibree',sports:['football'],targetOdds:5};

export async function GET(){return NextResponse.json(profile);}
export async function PUT(req:Request){
 const body=await req.json();
 profile={...profile,...body};
 return NextResponse.json(profile);
}