import {NextResponse} from 'next/server';
import {rankMatches, Risk} from '../../../../lib/ai-engine';

export async function GET(req:Request){
 const risk=(new URL(req.url).searchParams.get('risk')||'equilibree') as Risk;
 return NextResponse.json({data:rankMatches(risk)});
}