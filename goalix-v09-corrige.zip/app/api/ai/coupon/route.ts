import {NextResponse} from 'next/server';
import {generateCoupon, Risk} from '../../../../lib/ai-engine';

export async function POST(req:Request){
 const body=await req.json().catch(()=>({}));
 const risk=(body.risk||'equilibree') as Risk;
 const count=Number(body.count||3);
 return NextResponse.json(generateCoupon(risk,count));
}