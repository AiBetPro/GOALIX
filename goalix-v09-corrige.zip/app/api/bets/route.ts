import {NextResponse} from 'next/server';
import {prisma} from '../../../lib/prisma';

const DEMO_USER='demo-user';

export async function GET(){
 const user=await prisma.user.findUnique({where:{id:DEMO_USER},include:{bets:{include:{selections:true},orderBy:{createdAt:'desc'}},transactions:{orderBy:{createdAt:'desc'},take:30}}});
 if(!user) return NextResponse.json({error:'Utilisateur démo absent. Lancez le seed.'},{status:404});
 return NextResponse.json({wallet:{balance:user.balance.toString(),currency:user.currency},bets:user.bets,transactions:user.transactions});
}

export async function POST(req:Request){
 const body=await req.json();
 const stake=Number(body.stake), expected=Number(body.expectedOdds), selections=body.selections||[];
 if(!Number.isFinite(stake)||stake<=0||!selections.length) return NextResponse.json({error:'Mise ou coupon invalide'},{status:400});
 try{
  const result=await prisma.$transaction(async tx=>{
   const user=await tx.user.findUnique({where:{id:DEMO_USER}});
   if(!user) throw new Error('Utilisateur démo absent');
   if(stake>Number(user.balance)) throw new Error('Solde insuffisant');
   const total=selections.reduce((p:any,s:any)=>p*Number(s.odd),1);
   if(Math.abs(total-expected)>0.001) throw new Error('Les cotes ont changé. Actualisez le coupon.');
   const bet=await tx.bet.create({data:{userId:DEMO_USER,stake,totalOdds:total,potentialWin:stake*total,selections:{create:selections.map((s:any)=>({matchId:String(s.matchId),label:String(s.label),market:String(s.market),odd:Number(s.odd)}))}});
   const newBalance=Number(user.balance)-stake;
   await tx.user.update({where:{id:DEMO_USER},data:{balance:newBalance}});
   await tx.transaction.create({data:{userId:DEMO_USER,type:'BET',amount:-stake}});
   return {bet,balance:newBalance};
  });
  return NextResponse.json(result,{status:201});
 }catch(e){return NextResponse.json({error:String(e instanceof Error?e.message:e)},{status:400})}
}
