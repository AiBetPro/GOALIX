export type GoalixSelection = {
  id: string;
  matchId: string;
  match: string;
  league: string;
  market: string;
  choice: string;
  odds: number;
};

const SELECTIONS_KEY = 'goalix_selections';
const CODE_KEY = 'goalix_coupon_code';
const STAKE_KEY = 'goalix_stake';

export function getCouponSelections(): GoalixSelection[] {
  if (typeof window === 'undefined') return [];

  try {
    const saved = localStorage.getItem(SELECTIONS_KEY);
    if (!saved) return [];
    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveCouponSelections(selections: GoalixSelection[]) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(SELECTIONS_KEY, JSON.stringify(selections));
  window.dispatchEvent(new Event('goalix-coupon-updated'));
}

export function addOrReplaceSelection(selection: GoalixSelection) {
  const current = getCouponSelections();
  const withoutSameMarket = current.filter(
    (item) => !(item.matchId === selection.matchId && item.market === selection.market)
  );
  saveCouponSelections([...withoutSameMarket, selection]);
  ensureCouponCode();
}

export function removeCouponSelection(id: string) {
  const current = getCouponSelections();
  saveCouponSelections(current.filter((item) => item.id !== id));
}

export function clearGoalixCoupon() {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(SELECTIONS_KEY);
  localStorage.removeItem(CODE_KEY);
  localStorage.removeItem(STAKE_KEY);
  window.dispatchEvent(new Event('goalix-coupon-updated'));
}

export function generateCouponCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = 'GX-';
  for (let i = 0; i < 6; i++) {
    result += chars[Math.floor(Math.random() * chars.length)];
  }
  return result;
}

export function ensureCouponCode() {
  if (typeof window === 'undefined') return '';
  let code = localStorage.getItem(CODE_KEY);
  if (!code) {
    code = generateCouponCode();
    localStorage.setItem(CODE_KEY, code);
  }
  return code;
}

export function getCouponCode() {
  if (typeof window === 'undefined') return '';
  return localStorage.getItem(CODE_KEY) || '';
}
