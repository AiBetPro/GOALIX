'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import {
  addOrReplaceSelection,
  getCouponSelections,
  type GoalixSelection,
} from '@/lib/coupon';

type MatchInfo = {
  id: string;
  league: string;
  home: string;
  away: string;
  time: string;
};

type Selection = {
  id: string;
  label: string;
  odds: number;
};

type Market = {
  id: string;
  name: string;
  selections: Selection[];
};

const matches: Record<string, MatchInfo> = {
  'arsenal-chelsea': { id: 'arsenal-chelsea', league: 'Premier League', home: 'Arsenal', away: 'Chelsea', time: '18:00' },
  'barcelona-sevilla': { id: 'barcelona-sevilla', league: 'La Liga', home: 'Barcelona', away: 'Sevilla', time: '20:30' },
  'inter-milan': { id: 'inter-milan', league: 'Serie A', home: 'Inter', away: 'Milan', time: '21:00' },
  'psg-lyon': { id: 'psg-lyon', league: 'Ligue 1', home: 'PSG', away: 'Lyon', time: '21:00' },
  'real-atletico': { id: 'real-atletico', league: 'La Liga', home: 'Real Madrid', away: 'Atlético Madrid', time: '22:00' },
};

function createMarkets(home: string, away: string): Market[] {
  return [
    {
      id: 'result',
      name: 'Résultat du match',
      selections: [
        { id: 'home', label: home, odds: 1.65 },
        { id: 'draw', label: 'Match nul', odds: 3.70 },
        { id: 'away', label: away, odds: 4.90 },
      ],
    },
    {
      id: 'double-chance',
      name: 'Double chance',
      selections: [
        { id: '1x', label: '1X', odds: 1.20 },
        { id: 'x2', label: 'X2', odds: 1.85 },
        { id: '12', label: '12', odds: 1.30 },
      ],
    },
    {
      id: 'total-goals',
      name: 'Total buts',
      selections: [
        { id: 'over-15', label: 'Plus de 1,5', odds: 1.35 },
        { id: 'under-15', label: 'Moins de 1,5', odds: 2.80 },
        { id: 'over-25', label: 'Plus de 2,5', odds: 1.70 },
        { id: 'under-25', label: 'Moins de 2,5', odds: 2.10 },
        { id: 'over-35', label: 'Plus de 3,5', odds: 2.40 },
        { id: 'under-35', label: 'Moins de 3,5', odds: 1.50 },
      ],
    },
    {
      id: 'btts',
      name: 'Les deux équipes marquent',
      selections: [
        { id: 'yes', label: 'Oui', odds: 1.62 },
        { id: 'no', label: 'Non', odds: 2.15 },
      ],
    },
    {
      id: 'team-goals',
      name: 'Buts équipe',
      selections: [
        { id: 'home-over-05', label: `${home} +0,5`, odds: 1.25 },
        { id: 'home-over-15', label: `${home} +1,5`, odds: 1.75 },
        { id: 'away-over-05', label: `${away} +0,5`, odds: 1.55 },
        { id: 'away-over-15', label: `${away} +1,5`, odds: 2.30 },
      ],
    },
    {
      id: 'correct-score',
      name: 'Score exact',
      selections: [
        { id: 'score-10', label: '1 - 0', odds: 7.00 },
        { id: 'score-11', label: '1 - 1', odds: 6.50 },
        { id: 'score-20', label: '2 - 0', odds: 7.50 },
        { id: 'score-21', label: '2 - 1', odds: 8.00 },
        { id: 'score-22', label: '2 - 2', odds: 12.00 },
        { id: 'score-01', label: '0 - 1', odds: 10.00 },
      ],
    },
  ];
}

export default function MatchPage() {
  const params = useParams();
  const matchId = String(params?.id ?? 'arsenal-chelsea');
  const match = matches[matchId] ?? matches['arsenal-chelsea'];
  const markets = useMemo(() => createMarkets(match.home, match.away), [match.home, match.away]);

  const [coupon, setCoupon] = useState<GoalixSelection[]>([]);
  const [addedKey, setAddedKey] = useState<string | null>(null);

  useEffect(() => {
    setCoupon(getCouponSelections());

    const refresh = () => setCoupon(getCouponSelections());
    window.addEventListener('goalix-coupon-updated', refresh);
    window.addEventListener('storage', refresh);

    return () => {
      window.removeEventListener('goalix-coupon-updated', refresh);
      window.removeEventListener('storage', refresh);
    };
  }, []);

  function isSelected(marketName: string, selectionId: string) {
    return coupon.some(
      (item) =>
        item.matchId === match.id &&
        item.market === marketName &&
        item.id === `${match.id}-${marketName}-${selectionId}`
    );
  }

  function addToCoupon(marketName: string, selection: Selection) {
    const selectionKey = `${marketName}-${selection.id}`;
    const couponSelection: GoalixSelection = {
      id: `${match.id}-${marketName}-${selection.id}`,
      matchId: match.id,
      match: `${match.home} - ${match.away}`,
      league: match.league,
      market: marketName,
      choice: selection.label,
      odds: selection.odds,
    };

    addOrReplaceSelection(couponSelection);
    setCoupon(getCouponSelections());
    setAddedKey(selectionKey);
    setTimeout(() => setAddedKey(null), 1400);
  }

  return (
    <main className="min-h-screen bg-slate-50 pb-28">
      <header className="bg-slate-950 text-white">
        <div className="mx-auto max-w-3xl px-4 py-4">
          <div className="flex items-center justify-between gap-3">
            <Link href="/dashboard" className="rounded-xl bg-white/10 px-3 py-2 text-sm font-bold">← Retour</Link>
            <Link href="/bets" className="rounded-xl bg-emerald-500 px-3 py-2 text-sm font-black">🎟️ Coupon {coupon.length > 0 ? `(${coupon.length})` : ''}</Link>
          </div>

          <div className="mt-7 pb-3 text-center">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-emerald-400">{match.league}</p>
            <p className="mt-2 text-xs font-bold text-slate-400">Aujourd&apos;hui · {match.time}</p>

            <div className="mt-5 grid grid-cols-[1fr_auto_1fr] items-center gap-3">
              <div className="min-w-0">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-white/10 text-xl font-black">{match.home.charAt(0)}</div>
                <h1 className="mt-2 truncate text-lg font-black">{match.home}</h1>
              </div>
              <div className="text-center text-xs font-black text-slate-500">VS</div>
              <div className="min-w-0">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-white/10 text-xl font-black">{match.away.charAt(0)}</div>
                <h2 className="mt-2 truncate text-lg font-black">{match.away}</h2>
              </div>
            </div>

            <p className="mt-4 text-xs text-slate-500">Touchez une cote pour l&apos;ajouter ou modifier votre coupon.</p>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-3xl px-4 py-5">
        <div className="mb-5 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs leading-5 text-amber-800">
          ⚠️ Les cotes affichées actuellement sont des données de démonstration. Les vraies cotes Sportmonks seront intégrées ensuite.
        </div>

        <div className="mb-4">
          <p className="text-xs font-bold uppercase tracking-widest text-emerald-600">MARCHÉS DU MATCH</p>
          <h2 className="mt-1 text-2xl font-black text-slate-950">Choisissez votre pari</h2>
        </div>

        <div className="space-y-4">
          {markets.map((market) => (
            <section key={market.id} className="overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
              <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
                <h3 className="text-base font-black text-slate-950">{market.name}</h3>
                {coupon.some((item) => item.matchId === match.id && item.market === market.name) && (
                  <span className="text-xs font-black text-emerald-600">✓ Sélectionnée</span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2 p-3 sm:grid-cols-3">
                {market.selections.map((selection) => {
                  const key = `${market.id}-${selection.id}`;
                  const selected = isSelected(market.name, selection.id);
                  const justAdded = addedKey === key;

                  return (
                    <button
                      key={selection.id}
                      type="button"
                      onClick={() => addToCoupon(market.name, selection)}
                      className={`min-h-[74px] rounded-xl border px-3 py-3 text-left transition active:scale-[0.97] ${
                        selected || justAdded
                          ? 'border-emerald-500 bg-emerald-50 ring-2 ring-emerald-100'
                          : 'border-slate-200 bg-slate-50 hover:bg-slate-100'
                      }`}
                    >
                      <p className="truncate text-sm font-bold text-slate-800">{selection.label}</p>
                      <div className="mt-2 flex items-center justify-between gap-2">
                        <span className="text-lg font-black text-emerald-600">{selection.odds.toFixed(2)}</span>
                        {(selected || justAdded) && <span className="text-xs font-black text-emerald-600">✓</span>}
                      </div>
                    </button>
                  );
                })}
              </div>
            </section>
          ))}
        </div>

        <div className="sticky bottom-4 z-10 mt-6">
          <Link href="/bets" className="block w-full rounded-2xl bg-emerald-600 px-5 py-4 text-center text-base font-black text-white shadow-xl">
            🎟️ Voir mon coupon {coupon.length > 0 ? `· ${coupon.length} sélection${coupon.length > 1 ? 's' : ''}` : ''}
          </Link>
        </div>
      </div>
    </main>
  );
}
