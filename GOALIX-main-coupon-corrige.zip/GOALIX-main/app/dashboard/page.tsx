'use client';

import Link from 'next/link';
import { useState } from 'react';

type Match = {
  id: string;
  league: string;
  time: string;
  home: string;
  away: string;
  homeOdd: string;
  drawOdd: string;
  awayOdd: string;
};

const matches: Match[] = [
  { id: 'arsenal-chelsea', league: 'Premier League', time: '18:00', home: 'Arsenal', away: 'Chelsea', homeOdd: '1.65', drawOdd: '3.70', awayOdd: '4.90' },
  { id: 'barcelona-sevilla', league: 'La Liga', time: '20:30', home: 'Barcelona', away: 'Sevilla', homeOdd: '1.42', drawOdd: '4.40', awayOdd: '6.80' },
  { id: 'inter-milan', league: 'Serie A', time: '21:00', home: 'Inter', away: 'Milan', homeOdd: '1.75', drawOdd: '3.50', awayOdd: '4.30' },
  { id: 'psg-lyon', league: 'Ligue 1', time: '21:00', home: 'PSG', away: 'Lyon', homeOdd: '1.48', drawOdd: '4.20', awayOdd: '5.90' },
  { id: 'real-atletico', league: 'La Liga', time: '22:00', home: 'Real Madrid', away: 'Atlético Madrid', homeOdd: '1.72', drawOdd: '3.60', awayOdd: '4.60' },
];

const sports = [
  { icon: '⚽', name: 'Football', count: '245' },
  { icon: '🏀', name: 'Basketball', count: '38' },
  { icon: '🎾', name: 'Tennis', count: '64' },
  { icon: '🏎️', name: 'F1', count: '12' },
];

export default function DashboardPage() {
  const [search, setSearch] = useState('');
  const [selectedSport, setSelectedSport] = useState('Football');

  const filteredMatches = matches.filter((match) => {
    const text = `${match.home} ${match.away} ${match.league}`.toLowerCase();
    return text.includes(search.toLowerCase());
  });

  return (
    <main className="dashboard-page">
      <header className="dashboard-header">
        <Link href="/" className="dashboard-logo">GOA<span>LIX</span></Link>
        <Link href="/bets" className="dashboard-account" aria-label="Coupon">🎟️</Link>
      </header>

      <section className="balance-card">
        <div className="balance-top"><div><span>MON SOLDE</span><strong>0 FCFA</strong></div><div className="balance-icon">💳</div></div>
        <div className="balance-actions"><button>+ Dépôt</button><button>Retrait</button></div>
        <p>Mode démonstration — aucun argent réel.</p>
      </section>

      <div className="dashboard-search">
        <span>⌕</span>
        <input type="text" placeholder="Rechercher une équipe ou un match..." value={search} onChange={(event) => setSearch(event.target.value)} />
      </div>

      <section className="dashboard-section">
        <div className="dashboard-title"><div><span>EXPLORER</span><h2>Sports</h2></div><span className="dashboard-count">{sports.length}</span></div>
        <div className="sports-scroll">
          {sports.map((sport) => (
            <button key={sport.name} onClick={() => setSelectedSport(sport.name)} className={`dashboard-sport ${selectedSport === sport.name ? 'active' : ''}`}>
              <span className="sport-icon">{sport.icon}</span><strong>{sport.name}</strong><small>{sport.count} matchs</small>
            </button>
          ))}
        </div>
      </section>

      <section className="quick-actions">
        <Link href="/live" className="quick-card live-card"><div><span className="quick-icon">🔴</span><strong>Matchs Live</strong><small>Voir les matchs en direct</small></div><span className="quick-arrow">→</span></Link>
        <Link href="/ai-prono" className="quick-card ai-card"><div><span className="quick-icon">🤖</span><strong>IA Prono</strong><small>Générer un coupon intelligent</small></div><span className="quick-arrow">→</span></Link>
      </section>

      <section className="dashboard-section matches-dashboard">
        <div className="dashboard-title"><div><span>AUJOURD&apos;HUI</span><h2>Matchs populaires</h2></div><Link href="/live">Tout voir →</Link></div>
        <div className="dashboard-matches">
          {filteredMatches.length === 0 ? (
            <div className="no-results"><span>🔎</span><strong>Aucun match trouvé</strong><p>Essayez une autre recherche.</p></div>
          ) : filteredMatches.map((match) => (
            <article key={match.id} className="dashboard-match">
              <Link href={`/match/${match.id}`} className="block">
                <div className="match-header"><span>{match.league}</span><time>{match.time}</time></div>
                <div className="match-body">
                  <div className="dashboard-team"><div className="team-logo">{match.home.charAt(0)}</div><strong>{match.home}</strong></div>
                  <div className="dashboard-vs">VS</div>
                  <div className="dashboard-team"><div className="team-logo">{match.away.charAt(0)}</div><strong>{match.away}</strong></div>
                </div>
              </Link>
              <div className="odds-title">RÉSULTAT DU MATCH · OUVRIR POUR VOIR TOUS LES MARCHÉS</div>
              <div className="odds-grid">
                <Link href={`/match/${match.id}`}><small>1</small><strong>{match.homeOdd}</strong></Link>
                <Link href={`/match/${match.id}`}><small>X</small><strong>{match.drawOdd}</strong></Link>
                <Link href={`/match/${match.id}`}><small>2</small><strong>{match.awayOdd}</strong></Link>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
