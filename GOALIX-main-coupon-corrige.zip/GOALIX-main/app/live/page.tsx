'use client';

import Link from 'next/link';

type LiveMatch = {
  id: string;
  league: string;
  minute: string;
  home: string;
  away: string;
  homeScore: number;
  awayScore: number;
  events: string[];
};

const liveMatches: LiveMatch[] = [
  { id: 'arsenal-chelsea', league: 'Premier League', minute: "67'", home: 'Arsenal', away: 'Chelsea', homeScore: 2, awayScore: 1, events: ["⚽ 12' Arsenal", "⚽ 38' Chelsea", "⚽ 61' Arsenal"] },
  { id: 'barcelona-sevilla', league: 'La Liga', minute: "73'", home: 'Barcelona', away: 'Sevilla', homeScore: 1, awayScore: 0, events: ["⚽ 29' Barcelona", "🟨 54' Sevilla"] },
  { id: 'inter-milan', league: 'Serie A', minute: "41'", home: 'Inter', away: 'Milan', homeScore: 0, awayScore: 0, events: ["🟨 18' Inter", "🟨 35' Milan"] },
];

export default function LivePage() {
  return (
    <main className="min-h-screen bg-slate-50 pb-28">
      <header className="sticky top-0 z-50 border-b border-slate-800 bg-slate-950 text-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
          <Link href="/dashboard" className="flex items-center gap-2"><span className="text-xl">←</span><div><div className="text-lg font-black">GOALIX</div><div className="text-[10px] uppercase tracking-widest text-slate-400">Paris sportifs</div></div></Link>
          <Link href="/bets" className="rounded-xl bg-white/10 px-3 py-2 text-sm font-bold">🎟️ Coupon</Link>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-4 py-6">
        <div className="mb-5"><div className="mb-2 inline-flex items-center gap-2 rounded-full bg-red-100 px-3 py-1 text-xs font-bold text-red-600"><span className="h-2 w-2 animate-pulse rounded-full bg-red-500" />MATCHS EN DIRECT</div><h1 className="text-3xl font-black text-slate-950">Paris Live</h1><p className="mt-1 text-sm text-slate-500">Touchez un match pour ouvrir tous ses marchés et modifier votre coupon.</p></div>

        <div className="mb-5 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs leading-5 text-amber-800">⚠️ Les matchs et événements affichés sont actuellement des données de démonstration.</div>

        <div className="space-y-5">
          {liveMatches.map((match) => (
            <article key={match.id} className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
              <Link href={`/match/${match.id}`} className="block transition hover:bg-slate-50">
                <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3"><div><div className="text-xs font-bold uppercase tracking-wide text-slate-400">{match.league}</div><div className="mt-1 flex items-center gap-2"><span className="h-2 w-2 animate-pulse rounded-full bg-red-500" /><span className="text-xs font-black text-red-600">EN DIRECT</span><span className="text-xs font-bold text-slate-500">{match.minute}</span></div></div><span className="rounded-xl bg-slate-100 px-3 py-2 text-xs font-bold text-slate-700">Voir les marchés →</span></div>
                <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-4 px-4 py-6">
                  <div className="text-center"><div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-lg font-black">{match.home.slice(0, 2).toUpperCase()}</div><div className="text-sm font-black">{match.home}</div></div>
                  <div className="text-center"><div className="text-3xl font-black">{match.homeScore}<span className="mx-1 text-slate-300">-</span>{match.awayScore}</div><div className="mt-1 text-[11px] font-bold text-red-500">{match.minute}</div></div>
                  <div className="text-center"><div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-lg font-black">{match.away.slice(0, 2).toUpperCase()}</div><div className="text-sm font-black">{match.away}</div></div>
                </div>
              </Link>
              <div className="border-t border-slate-100 px-4 py-3"><div className="mb-2 text-xs font-black uppercase tracking-wide text-slate-400">Événements</div><div className="flex flex-wrap gap-2">{match.events.map((event, index) => <span key={`${match.id}-${index}`} className="rounded-lg bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-600">{event}</span>)}</div></div>
              <Link href={`/match/${match.id}`} className="block border-t border-slate-100 px-4 py-3 text-center text-sm font-black text-emerald-600">📊 Ouvrir le match et voir tous les marchés</Link>
            </article>
          ))}
        </div>

        <Link href="/ai-prono" className="mt-6 block rounded-3xl bg-slate-950 p-5 text-white"><div className="text-xs font-black uppercase tracking-widest text-emerald-400">🤖 GOALIX IA</div><h2 className="mt-2 text-xl font-black">Besoin d&apos;une analyse ?</h2><p className="mt-1 text-sm text-slate-400">Découvrez les analyses indicatives de GOALIX IA.</p></Link>
      </section>
    </main>
  );
}
