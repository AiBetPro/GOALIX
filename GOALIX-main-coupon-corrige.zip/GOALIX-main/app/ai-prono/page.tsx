'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import {
  addOrReplaceSelection,
  getCouponSelections,
  removeCouponSelection,
  type GoalixSelection,
} from '@/lib/coupon';

type RiskProfile = 'prudent' | 'equilibre' | 'audacieux';

type Match = {
  id: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  selection: string;
  odds: number;
  score: number;
  probability: number;
  risk: RiskProfile;
  reason: string;
};

const matches: Match[] = [
  { id: 'arsenal-chelsea', league: 'Premier League', homeTeam: 'Arsenal', awayTeam: 'Chelsea', selection: 'Arsenal gagne', odds: 1.65, score: 82, probability: 61, risk: 'prudent', reason: 'La cote disponible favorise Arsenal. Cette analyse est indicative.' },
  { id: 'barcelona-sevilla', league: 'La Liga', homeTeam: 'Barcelona', awayTeam: 'Sevilla', selection: 'Barcelona gagne', odds: 1.42, score: 91, probability: 70, risk: 'prudent', reason: 'La cote disponible favorise Barcelona. Cette analyse est indicative.' },
  { id: 'inter-milan', league: 'Serie A', homeTeam: 'Inter', awayTeam: 'Milan', selection: 'Inter gagne', odds: 1.75, score: 76, probability: 57, risk: 'equilibre', reason: 'La cote présente ici un compromis entre risque et gain potentiel.' },
];

const riskLabels: Record<RiskProfile, string> = { prudent: 'Prudent', equilibre: 'Équilibré', audacieux: 'Audacieux' };

export default function AIPronoPage() {
  const [risk, setRisk] = useState<RiskProfile>('prudent');
  const [coupon, setCoupon] = useState<GoalixSelection[]>([]);
  const [generated, setGenerated] = useState(false);

  useEffect(() => {
    const refresh = () => setCoupon(getCouponSelections());
    refresh();
    window.addEventListener('goalix-coupon-updated', refresh);
    window.addEventListener('storage', refresh);
    return () => {
      window.removeEventListener('goalix-coupon-updated', refresh);
      window.removeEventListener('storage', refresh);
    };
  }, []);

  const filteredMatches = useMemo(() => {
    if (risk === 'prudent') return matches.filter((match) => match.risk === 'prudent');
    if (risk === 'equilibre') return matches.filter((match) => match.risk !== 'audacieux');
    return matches;
  }, [risk]);

  const totalOdds = useMemo(() => coupon.length ? coupon.reduce((total, item) => total * Number(item.odds), 1) : 0, [coupon]);

  function addAISelection(match: Match) {
    const selection: GoalixSelection = {
      id: `${match.id}-IA Prono-${match.selection}`,
      matchId: match.id,
      match: `${match.homeTeam} - ${match.awayTeam}`,
      league: match.league,
      market: 'IA Prono',
      choice: match.selection,
      odds: match.odds,
    };
    addOrReplaceSelection(selection);
    setCoupon(getCouponSelections());
  }

  function removeAISelection(match: Match) {
    const item = coupon.find((selection) => selection.matchId === match.id && selection.market === 'IA Prono');
    if (item) removeCouponSelection(item.id);
    setCoupon(getCouponSelections());
  }

  function generateCoupon() {
    filteredMatches.slice(0, risk === 'prudent' ? 2 : 3).forEach(addAISelection);
    setTimeout(() => setCoupon(getCouponSelections()), 0);
    setGenerated(true);
  }

  return (
    <main className="ai-page">
      <section className="ai-brand"><div className="ai-orbit"><div className="ai-logo-core"><span>G</span></div></div><div className="ai-brand-name">GOA<span>LIX</span></div><div className="ai-brand-label"><span className="ai-status-dot" />ARTIFICIAL INTELLIGENCE</div></section>

      <section className="ai-intro"><div className="ai-eyebrow">🤖 GOALIX AI</div><h1>IA <span>Prono</span></h1><p>Analysez les matchs et utilisez les recommandations comme point de départ pour construire votre coupon.</p></section>

      <section className="ai-risk-card">
        <div className="ai-section-label">VOTRE PROFIL</div>
        <h2>Quel style de pari recherchez-vous ?</h2>
        <div className="ai-risk-grid">
          {(['prudent', 'equilibre', 'audacieux'] as RiskProfile[]).map((item) => (
            <button key={item} onClick={() => { setRisk(item); setGenerated(false); }} className={`ai-risk-button ${risk === item ? 'active' : ''} ${item}`}>
              <span className="risk-icon">{item === 'prudent' ? '🟢' : item === 'equilibre' ? '🟡' : '🔴'}</span><span>{riskLabels[item]}</span>
            </button>
          ))}
        </div>
        <button onClick={generateCoupon} className="ai-generate-button"><span>🤖</span>Générer mon coupon IA<span className="arrow">→</span></button>
      </section>

      {generated && <div className="ai-success"><div className="success-icon">✓</div><div><strong>Coupon IA généré</strong><p>Les sélections ont été ajoutées à votre coupon GOALIX.</p></div></div>}

      <section className="ai-matches">
        <div className="ai-section-heading"><div><span>ANALYSE GOALIX</span><h2>Matchs recommandés</h2></div><div className="match-count">{filteredMatches.length}</div></div>
        <div className="ai-match-list">
          {filteredMatches.map((match) => {
            const isSelected = coupon.some((item) => item.matchId === match.id && item.market === 'IA Prono');
            return (
              <article key={match.id} className={`ai-match-card ${isSelected ? 'selected' : ''}`}>
                <Link href={`/match/${match.id}`} className="block">
                  <div className="match-top"><span>{match.league}</span><div className="ai-score"><small>IA SCORE</small><strong>{match.score}</strong></div></div>
                  <div className="match-teams"><strong>{match.homeTeam}</strong><div className="match-vs">VS</div><strong>{match.awayTeam}</strong></div>
                  <div className="ai-selection"><span>PRONOSTIC</span><strong>{match.selection}</strong><b>{match.odds.toFixed(2)}</b></div>
                  <div className="ai-stat-grid"><div><small>Probabilité indicative</small><strong>{match.probability}%</strong></div><div><small>Niveau</small><strong>{riskLabels[match.risk]}</strong></div></div>
                  <div className="ai-reason"><span>💡</span><p>{match.reason}</p></div>
                  <div className="mt-3 text-center text-xs font-black text-emerald-600">Voir tous les marchés →</div>
                </Link>
                <button onClick={() => isSelected ? removeAISelection(match) : addAISelection(match)} className={`ai-add-button ${isSelected ? 'remove' : ''}`}>
                  {isSelected ? '✓ Retirer du coupon' : '+ Ajouter au coupon'}
                </button>
              </article>
            );
          })}
        </div>
      </section>

      <section className="ai-coupon">
        <div className="coupon-header"><div><span>🎟️</span><div><small>GOALIX</small><h2>Mon coupon</h2></div></div><strong>{coupon.length}</strong></div>
        {coupon.length === 0 ? <div className="coupon-empty"><div>🎟️</div><p>Aucun pari sélectionné</p><small>Ajoutez une recommandation ou ouvrez un match pour choisir un marché.</small></div> : <><div className="coupon-selections">{coupon.map((item) => <Link key={item.id} href={`/match/${item.matchId}`} className="coupon-selection"><div><strong>{item.match}</strong><span>{item.market} · {item.choice}</span></div><b>{item.odds.toFixed(2)}</b></Link>)}</div><div className="coupon-total"><span>Cote totale</span><strong>{totalOdds.toFixed(2)}</strong></div></>}
        <Link href="/bets" className="ai-open-coupon">Ouvrir mon coupon <span>→</span></Link>
      </section>

      <div className="ai-warning">⚠️ Les analyses et probabilités sont indicatives. Elles ne garantissent aucun résultat. Les paris sportifs comportent un risque de perte.</div>
      <footer className="ai-footer"><strong>GOA<span>LIX</span></strong><p>Sports Betting & AI Predictions</p></footer>
    </main>
  );
}
