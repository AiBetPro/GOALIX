'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import {
  clearGoalixCoupon,
  getCouponCode,
  getCouponSelections,
  removeCouponSelection,
  type GoalixSelection,
} from '@/lib/coupon';

export default function BetsPage() {
  const [selections, setSelections] = useState<GoalixSelection[]>([]);
  const [stake, setStake] = useState('');
  const [couponCode, setCouponCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [validated, setValidated] = useState(false);

  function refreshCoupon() {
    setSelections(getCouponSelections());
    setCouponCode(getCouponCode());
    setStake(localStorage.getItem('goalix_stake') || '');
  }

  useEffect(() => {
    refreshCoupon();
    window.addEventListener('goalix-coupon-updated', refreshCoupon);
    window.addEventListener('storage', refreshCoupon);
    return () => {
      window.removeEventListener('goalix-coupon-updated', refreshCoupon);
      window.removeEventListener('storage', refreshCoupon);
    };
  }, []);

  useEffect(() => {
    localStorage.setItem('goalix_stake', stake);
  }, [stake]);

  const totalOdds = useMemo(() => {
    if (!selections.length) return 0;
    return selections.reduce((total, item) => total * Number(item.odds), 1);
  }, [selections]);

  const potentialWin = useMemo(() => {
    const value = Number(stake);
    return value > 0 ? value * totalOdds : 0;
  }, [stake, totalOdds]);

  function removeSelection(id: string) {
    removeCouponSelection(id);
    setSelections(getCouponSelections());
    setValidated(false);
  }

  function clearCoupon() {
    clearGoalixCoupon();
    setSelections([]);
    setStake('');
    setCouponCode('');
    setCopied(false);
    setValidated(false);
  }

  async function shareCoupon() {
    if (!couponCode || !selections.length) return;

    const text = [
      '🎟️ Coupon GOALIX',
      `Code : ${couponCode}`,
      `Paris : ${selections.length}`,
      `Cote totale : ${totalOdds.toFixed(2)}`,
      '',
      ...selections.map(
        (item, index) =>
          `${index + 1}. ${item.match} — ${item.market} — ${item.choice} @ ${item.odds.toFixed(2)}`
      ),
    ].join('\n');

    try {
      if (navigator.share) {
        await navigator.share({ title: 'Coupon GOALIX', text });
      } else {
        await navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }
    } catch {
      // L'utilisateur peut simplement fermer la fenêtre de partage.
    }
  }

  async function copyCode() {
    if (!couponCode) return;
    try {
      await navigator.clipboard.writeText(couponCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard indisponible sur certains navigateurs.
    }
  }

  function validateCoupon() {
    if (!selections.length) return;
    if (!stake || Number(stake) <= 0) return;
    setValidated(true);
  }

  return (
    <main className="min-h-screen bg-[#111517] pb-8 text-white">
      {/* TOP BAR */}
      <header className="sticky top-0 z-50 border-b border-white/10 bg-[#15191b]/95 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-4">
          <Link href="/dashboard" className="text-xl font-black tracking-tight">
            GOA<span className="text-lime-400">LIX</span>
          </Link>

          <div className="rounded-full bg-[#272c2f] p-1 text-sm font-bold">
            <span className="inline-flex rounded-full bg-[#3a4144] px-4 py-2 shadow-inner">
              Coupon de pari {selections.length > 0 && <b className="ml-2 text-lime-400">{selections.length}</b>}
            </span>
            <Link href="/bets" className="ml-1 inline-flex px-3 py-2 text-slate-400">
              Mes paris
            </Link>
          </div>

          <span className="text-sm font-black text-slate-300">FCFA</span>
        </div>
      </header>

      <div className="mx-auto max-w-3xl px-4 py-4">
        {/* EMPTY STATE */}
        {selections.length === 0 ? (
          <section className="min-h-[calc(100vh-110px)] text-center">
            <div className="rounded-3xl bg-[#22272a] p-5 text-left shadow-sm">
              <label className="text-lg font-medium text-slate-100">Code de réservation</label>
              <div className="mt-3 flex h-16 items-center rounded-2xl border-2 border-slate-500 px-4 text-slate-500">
                Entrer le code de réservation
              </div>
              <button className="mt-5 w-full rounded-2xl bg-lime-400 px-5 py-4 text-base font-black text-[#172000]">
                CHARGER LE COUPON
              </button>
            </div>

            <div className="mx-auto mt-20 max-w-sm">
              <div className="text-7xl">🎟️</div>
              <h1 className="mt-8 text-2xl font-black">Votre coupon de pari est vide</h1>
              <p className="mt-3 text-sm leading-6 text-slate-400">
                Sélectionnez un match et un marché pour commencer votre coupon.
              </p>

              <Link
                href="/dashboard"
                className="mt-8 block rounded-2xl bg-[#252a2d] px-5 py-4 font-black text-white"
              >
                DÉCOUVRIR PLUS DE SPORTS
              </Link>
            </div>
          </section>
        ) : (
          <section>
            {/* CODE + ACTIONS */}
            <div className="rounded-3xl bg-[#22272a] p-4 shadow-sm">
              <div className="flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={shareCoupon}
                  className="font-bold underline underline-offset-4"
                >
                  ↗ Partager le code
                </button>

                <button
                  type="button"
                  onClick={clearCoupon}
                  className="font-bold underline underline-offset-4"
                >
                  Effacer le coupon
                </button>
              </div>

              <div className="mt-4 rounded-2xl bg-[#171b1d] p-4">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Code de réservation</p>
                <div className="mt-2 flex items-center justify-between gap-3">
                  <strong className="text-2xl tracking-[0.18em] text-lime-400">{couponCode}</strong>
                  <button
                    type="button"
                    onClick={copyCode}
                    className="rounded-xl bg-white/10 px-3 py-2 text-xs font-bold"
                  >
                    {copied ? '✓ Copié' : 'Copier'}
                  </button>
                </div>
              </div>

              <div className="mt-4 rounded-2xl bg-[#0b6e7d] p-4 text-sm leading-6 text-white">
                Félicitations ! Ces sélections composent votre coupon GOALIX. Ajoutez ou modifiez vos événements avant validation.
              </div>
            </div>

            {/* SELECTIONS */}
            <div className="mt-4 space-y-2">
              {selections.map((item, index) => (
                <div key={item.id} className="flex overflow-hidden rounded-2xl border border-white/10 bg-[#22272a]">
                  <button
                    type="button"
                    onClick={() => removeSelection(item.id)}
                    aria-label={`Supprimer ${item.match}`}
                    className="w-14 shrink-0 border-r border-white/10 text-3xl text-slate-400 hover:text-white"
                  >
                    ×
                  </button>

                  <Link
                    href={`/match/${item.matchId}`}
                    className="min-w-0 flex-1 p-4 transition hover:bg-white/[0.03]"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="truncate text-base font-medium text-slate-100">⚽ {item.match}</p>
                        <p className="mt-2 text-sm font-black text-white">
                          {item.market} <span className="text-slate-500">|</span> {item.choice}
                        </p>
                        <p className="mt-1 text-xs text-slate-500">
                          {item.league} · Sélection {index + 1}
                        </p>
                      </div>
                      <strong className="shrink-0 text-lg font-black text-white">{Number(item.odds).toFixed(2)}</strong>
                    </div>
                  </Link>
                </div>
              ))}
            </div>

            {/* SUMMARY */}
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div className="rounded-2xl bg-[#22272a] p-4">
                <p className="text-xs text-slate-400">Cote totale</p>
                <strong className="mt-1 block text-2xl text-lime-400">{totalOdds.toFixed(2)}</strong>
              </div>
              <div className="rounded-2xl bg-[#22272a] p-4">
                <p className="text-xs text-slate-400">Sélections</p>
                <strong className="mt-1 block text-2xl">{selections.length}</strong>
              </div>
            </div>

            {/* STAKE */}
            <div className="mt-2 rounded-2xl bg-[#22272a] p-4">
              <label htmlFor="stake" className="text-sm text-slate-400">Mise</label>
              <div className="mt-2 flex items-center gap-3">
                <input
                  id="stake"
                  type="number"
                  min="0"
                  inputMode="decimal"
                  value={stake}
                  onChange={(e) => {
                    setStake(e.target.value);
                    setValidated(false);
                  }}
                  placeholder="500"
                  className="w-full bg-transparent text-3xl font-black outline-none placeholder:text-slate-600"
                />
                <span className="font-black text-lime-400">FCFA</span>
              </div>
            </div>

            <div className="mt-2 rounded-2xl bg-lime-400 p-5 text-[#172000]">
              <p className="text-sm font-bold">Gain potentiel</p>
              <strong className="mt-1 block text-3xl font-black">
                {potentialWin.toLocaleString('fr-FR', { maximumFractionDigits: 0 })} FCFA
              </strong>
            </div>

            <button
              type="button"
              onClick={validateCoupon}
              className="mt-4 w-full rounded-2xl bg-white py-4 text-lg font-black text-slate-950"
            >
              {validated ? '✓ Coupon enregistré' : 'Valider le coupon'}
            </button>
          </section>
        )}
      </div>
    </main>
  );
}
